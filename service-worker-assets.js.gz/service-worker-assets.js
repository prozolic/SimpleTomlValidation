self.assetsManifest = {
  "version": "x+TTmpKj",
  "assets": [
    {
      "hash": "sha256-EnMz1ovVbz6/1UhgTCiBSX56jh4mWcdfUD2WXYTo3Ag=",
      "url": "SimpleTomlValidation.styles.css"
    },
    {
      "hash": "sha256-8acamWXOwn3b3oW8XQo4q/cj/T5BMx666uKPFJFTgwo=",
      "url": "_content/BlazorMonaco/jsInterop.js"
    },
    {
      "hash": "sha256-9BO3m53qSbzYdf3PaXdEeqNDcr3tjsTWoRve7x8NR1k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/_commonjsHelpers-CT9FvmAN.js"
    },
    {
      "hash": "sha256-gOQ6UyaNakxjL/mYW+4efQxpEMzq3eRkqiNL820KZzc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/abap-D-t0cyap.js"
    },
    {
      "hash": "sha256-9lpamifStsKi7FWmcEhgc8p2ID/GPVo++RqIn+PGvag=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/apex-CcIm7xu6.js"
    },
    {
      "hash": "sha256-wFNuIoIN3xjS2sseEcbnjCWuiFQ1L8mRo54icAEwEtA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/css.worker-HnVq6Ewq.js"
    },
    {
      "hash": "sha256-gWsLmlqlYmy9KbGc90p5KCm63rgpIxa4ixBG3A7PK0w=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/editor.worker-Be8ye1pW.js"
    },
    {
      "hash": "sha256-77Z0GnVN+CnyPjom9TcLEP0hs2TZ0cToTCN60Mnji4s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/html.worker-B51mlPHg.js"
    },
    {
      "hash": "sha256-aCKMQM/xT15dQNQOK9yk/KxTvWnVOgQgo/dwoDwsUdY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/json.worker-DKiEKt88.js"
    },
    {
      "hash": "sha256-DD0ytygVvSAmf1VweVYpX4xACSPZqR8lJosN7jSBLkc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/assets/ts.worker-CMbG-7ft.js"
    },
    {
      "hash": "sha256-tfnH0lwsx0ihyWXJVi3ouTS4LmTfpeQjxxIch1kJDdI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/azcli-BA0tQDCg.js"
    },
    {
      "hash": "sha256-Jwi7pqrdMNU81Vi+Z4uWKYqclutfryFIY4fAOQXyH6k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/monaco.contribution.js"
    },
    {
      "hash": "sha256-5bvU0HGdFXzH36awfgfaQQTlLmh7l6ag3JTm1MtGFLE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/bat-C397hTD6.js"
    },
    {
      "hash": "sha256-OZKJCcKyRL8T3Sqth39TlmukO1uWRCpiBTBsZw/XOo4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/bicep-DF5aW17k.js"
    },
    {
      "hash": "sha256-+CSb3k7ayiKEGQegh/t8edrYHnBIrGFkk30YSyMQbTU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cameligo-plsz8qhj.js"
    },
    {
      "hash": "sha256-bepRRIXupzNrMTQ+qeypwY8/POaeCtUtOdr49Bvq4xE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/clojure-Y2auQMzK.js"
    },
    {
      "hash": "sha256-9M4C1cQosPhMfta1Dt7HKaZMB0S5gWShSCQ7Lhy9LW0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/coffee-Bu45yuWE.js"
    },
    {
      "hash": "sha256-aRCGApVRvHz7tf8VfgGpNXFaNcgzDcOMh5sGmhzcBow=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cpp-CkKPQIni.js"
    },
    {
      "hash": "sha256-dHwyzJamVfz4OZ+P+NmcSnPDTVKa/Rl9y9qai6HrBZU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/csharp-CX28MZyh.js"
    },
    {
      "hash": "sha256-C0d8Rt9pGTuq/J/OzBaFgkTBaP8PjeOjMqkiFxjhKk4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/csp-D8uWnyxW.js"
    },
    {
      "hash": "sha256-fiOzluv2MTnD6KSQ1NDO5yBwvgy8wWdR4h5253cluh0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/css-CaeNmE3S.js"
    },
    {
      "hash": "sha256-M8jMCQYW9/k3YYEMp4RNnFqRH8itxNn+73GRv0OKL00=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cssMode-CjiAH6dQ.js"
    },
    {
      "hash": "sha256-pViDNWzCxUpWA4P5opFZIodfT+b+QUkAa1uPkjLCunM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/cypher-DVThT8BS.js"
    },
    {
      "hash": "sha256-WnOhyB0MV3dAWP1Dr9JJF9sCEnw6qZa5uYLG8Zeuy+A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/dart-CmGfCvrO.js"
    },
    {
      "hash": "sha256-hNkNle9yLS1jzV4KSVrEhMtg1mPw5k/8AzqN6NuADRc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/dockerfile-CZqqYdch.js"
    },
    {
      "hash": "sha256-KpbcHRroDcp5FpyhM6FHWxR5tht04W9fu8/EocBWSCg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ecl-30fUercY.js"
    },
    {
      "hash": "sha256-wQ0AWP4O5dLEbDtsuyhHRAe+XUWto1lz8yMFYfgsTeU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor.api-CalNCsUg.js"
    },
    {
      "hash": "sha256-22wc1geUOoYbR8dmDQ7wLvZPcXMZTXxLi85cmIFW5fg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.css"
    },
    {
      "hash": "sha256-6M2LNLDMEHWa1UGdYlO8srkbU5WAq4V+RvKvkJbY40g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.js"
    },
    {
      "hash": "sha256-EtiGC+N7wzF4njvtrGWsYJaPsMwKXM2nLT6sCZJhhwE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/elixir-xjPaIfzF.js"
    },
    {
      "hash": "sha256-LMbJ9s8BlVe/62yzE+DWUESvWSDKC5ZNxi+WDUcPDgw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/flow9-DqtmStfK.js"
    },
    {
      "hash": "sha256-x2+wf18NvZTqugpuPw6FmLvZEXYWkJWIS53ccO03P/o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/freemarker2-Cz_sV6Md.js"
    },
    {
      "hash": "sha256-i/u1g0QR8LFr2SxFM4XjO22TqYdGNYx56v3KDlLJ6To=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/fsharp-BOMdg4U1.js"
    },
    {
      "hash": "sha256-rxNfyjMoG+jASbBicdOKeGp7gU3mp7Oxo63jHRgBnCo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/go-D_hbi-Jt.js"
    },
    {
      "hash": "sha256-xI3IzmdxyDIMUYAPOY7YkI/e1EvdMLwlv3NfrPO5+mg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/graphql-CKUU4kLG.js"
    },
    {
      "hash": "sha256-2iskmlrc4Ga4qRRvm87TsBg37LNx8o1drEbKBpuVNwA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/handlebars-OwglfO-1.js"
    },
    {
      "hash": "sha256-omDbRZkR+DjGqjMbbvqEHV/ZNg7CU1Qf6gFaYllLQpY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/hcl-DTaboeZW.js"
    },
    {
      "hash": "sha256-+AvKdpbABAFbchKYJ/t8aVtujNRT88gZnTcFmkn7dik=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/html-Pa1xEWsY.js"
    },
    {
      "hash": "sha256-xBF78OahwWtTFGbQPyCS5PQ3MFG+AiuHMZ1zezTuGRA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/htmlMode-Bz67EXwp.js"
    },
    {
      "hash": "sha256-tPv80rAFiBsPy9v9ZCGs/UYXF9s1WFxm0gMm55oS+bg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ini-CsNwO04R.js"
    },
    {
      "hash": "sha256-og/08ge8pvRX9i9dh12gTpgdZr3lCpd+jSwL5H6Rqq8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/java-CI4ZMsH9.js"
    },
    {
      "hash": "sha256-9gFaGWAxs++PF2ilnTgzNR7QhACY61iZIdVBzFCgmFM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/javascript-PczUCGdz.js"
    },
    {
      "hash": "sha256-SskM3lDr9du3pDttEFOVUQYP1+psnSPs+SNIwzT43/4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/jsonMode-DULH5oaX.js"
    },
    {
      "hash": "sha256-KRzyMnE47PKPjYkEWnl4rQZdK//1lXW4MsXZvYFOliM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/julia-BwzEvaQw.js"
    },
    {
      "hash": "sha256-4wzz5imU58MoR1QqeRUE6t8CnbwJJZTi4Ffnn+F8AVk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/kotlin-IUYPiTV8.js"
    },
    {
      "hash": "sha256-9xHU+iZuqXlmedd0P2IOnrcDYPRmwcSstZZNUl2rYCU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/monaco.contribution.js"
    },
    {
      "hash": "sha256-Aim9Jbj2Plt53FM9tiu+3YlbzEFEjY4u46EVCtUxgGI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/monaco.contribution.js"
    },
    {
      "hash": "sha256-n/SCOGgw09YNa0HVLaKJLbrAetYfvSIbGbYp6CkAlfU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/monaco.contribution.js"
    },
    {
      "hash": "sha256-A/8l9bBQBhNHtN5FKH94FD3hIQMagiICdmpW7LXoOe8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/monaco.contribution.js"
    },
    {
      "hash": "sha256-48AMT7TpnqA57EkwjWN/81gf3Rq2lbGKitH3KZ/kKKQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/less-C0eDYdqa.js"
    },
    {
      "hash": "sha256-+8zZE8Uk6ZLKwNPD5d3DHDwtxnwExwTkfymION0I7R0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lexon-iON-Kj97.js"
    },
    {
      "hash": "sha256-gyJFO33+1QX6gJ1wAHrOXgYdmAiB12Pc8p5xtKAY1ic=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/liquid-DqKjdPGy.js"
    },
    {
      "hash": "sha256-NbWd+AtBqLc78c6xWbRPBAVnwqtT9Od6PQAtncOdVdE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.js"
    },
    {
      "hash": "sha256-5VzVrcwLCfc4EEvX3Dn15YZbtyLcv6+gPbevnkuwIa0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lspLanguageFeatures-kM9O9rjY.js"
    },
    {
      "hash": "sha256-FuNuZfMu62ML5GIrYGbULr8Ds10qpg+N3YhO6MK8hEg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/lua-DtygF91M.js"
    },
    {
      "hash": "sha256-jNFIePfyv4yhKTpH42j2s1HW69ZnoHIEmZkoHbMG3xo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/m3-CsR4AuFi.js"
    },
    {
      "hash": "sha256-2quKUVDAndOTrKGreCvWob8TwSsvlhozqEIJMsa+MsU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/markdown-C_rD0bIw.js"
    },
    {
      "hash": "sha256-VcJ68Oa1e/83Nx4M9TlLnlP4I19kS+kJ2ZIe5M9e6N8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mdx-DEWtB1K5.js"
    },
    {
      "hash": "sha256-bJNveIqbJ7hGSkksCn5itDnK/xsFvqLrWoN7ZjZjzwg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mips-CiYP61RB.js"
    },
    {
      "hash": "sha256-mFQ4nY7RWD/XUIOmWhUMfirvDHm2tiZyoDuRJU07efo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/monaco.contribution-D2OdxNBt.js"
    },
    {
      "hash": "sha256-Mq3F62KYb7sghRox51qZfSxzDKRO4/QsB9fl0M+uwEk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/monaco.contribution-DO3azKX8.js"
    },
    {
      "hash": "sha256-d7Nn5OgT1xno7FQZ2R7SV7OucwpkoC6QGDCwILe/Rzc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/monaco.contribution-EcChJV6a.js"
    },
    {
      "hash": "sha256-B1nhZarjSy90LaIDosHrZtDMCKMHpUvXa+NX9A5IogE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/monaco.contribution-qLAYrEOP.js"
    },
    {
      "hash": "sha256-wyeRygo2HYBfqS2S8H0xa0WbrazF3VHvvHYOr5ForoM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/msdax-C38-sJlp.js"
    },
    {
      "hash": "sha256-2afAEv1d1VgQSI2SjrDk3D5OjIVsXUWkl9ArSt4SRRA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/mysql-CdtbpvbG.js"
    },
    {
      "hash": "sha256-tnZTuLFQwBk8H3xGynPpciaybnk0mbqFOz4fTnshX2U=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages-loader.js"
    },
    {
      "hash": "sha256-H8Nez5ZvJFE+KfCHz6P6K/1xc/rBphM8ZZv4Xp5trRg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.cs.js.js"
    },
    {
      "hash": "sha256-3islIrMT5dAFXuNSQp1l9JLUOhCoyNIpgRgzH226jKU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.de.js.js"
    },
    {
      "hash": "sha256-BruCRYIijrGG/bkWGjHwQ6R7lP061gda5yE0GbmxWR4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.es.js.js"
    },
    {
      "hash": "sha256-X9LnmiK0k56/tZ6LiLo69Yp2GJ1x/ErP33GJJOga+a4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.fr.js.js"
    },
    {
      "hash": "sha256-nbwfQNibqCBYuh3r8n/zN1uyRjiTo1YfO2RRlHrM8g8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.it.js.js"
    },
    {
      "hash": "sha256-jEK3A8xrOoO5Hof3LAVxpoYv3aRpEpDldrPx2uUKrYk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ja.js.js"
    },
    {
      "hash": "sha256-b905flq3MRXAR1yAr5dCLnRLMXQfrx/PpViaHYU3lsc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.js.js"
    },
    {
      "hash": "sha256-69jXTmnzZYQaAMzB002EuxJKr2i+AyHeeQx60Er+q+o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ko.js.js"
    },
    {
      "hash": "sha256-OzyHSaCoNtmSO+5lDxznshw4nhNv+FM8M3zwy9W4Gho=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.pl.js.js"
    },
    {
      "hash": "sha256-b+crxagCB8VLm2N9yM4X5vY8hzCq80HFNhlKFJPLnk4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.pt-br.js.js"
    },
    {
      "hash": "sha256-Cx+2bB1IS3gq57cZQhnmAIYI07Hp/t8l7fnxRkKPbMU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ru.js.js"
    },
    {
      "hash": "sha256-x5O3qY4yoXl4iXtpqPoJNthFPF3mT8quyE1ILgPwpS0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.tr.js.js"
    },
    {
      "hash": "sha256-Rk/3bdMbbTnKSJaJOB+WYdbjbjg08yaClHgvVVXbE+w=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-cn.js.js"
    },
    {
      "hash": "sha256-90S1dI43XRTo4qczdOw0CUZ9SxFv+WBk8uE79G3Knt4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-tw.js.js"
    },
    {
      "hash": "sha256-HNb5Jl6MpmNIy5dv/FEO2v9pl6bY7clrZ9Z01HmXiZ8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/objective-c-CntZFaHX.js"
    },
    {
      "hash": "sha256-08/cmiQZuMrviMmo2OSFcJJCAwD51fImEgO3gJxBlD8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pascal-r6kuqfl_.js"
    },
    {
      "hash": "sha256-BKJoIs+4zmWL1bccEpUuOX5nX2QoAIFWTr5Zx2T8GTk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pascaligo-BiXoTmXh.js"
    },
    {
      "hash": "sha256-Ho2O0egbGS2Yrx0KcU28yzOLxfo1V9augidBlLc3E6E=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/perl-DABw_TcH.js"
    },
    {
      "hash": "sha256-N0HbsmI8cWd+Ph01fmbcgWcSn7zdxAUp4TQ4oPlpxig=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pgsql-me_jFXeX.js"
    },
    {
      "hash": "sha256-6DTQyv3f17Dzqo0p4wqZVmgK2IGURsXL8cb18PANZyw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/php-D_kh-9LK.js"
    },
    {
      "hash": "sha256-47Wws82C6cocKJdakBnadevZcrI4FR/7D+8PFcirhH8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pla-VfZjczW0.js"
    },
    {
      "hash": "sha256-C4Mvf9oB+2y94UC1YuoRNY1cqLHua98NtZFQGdA1yUI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/postiats-BBSzz8Pk.js"
    },
    {
      "hash": "sha256-7g6bQjmnACjGlHr8ipMtkvuF8I0cSYCJRK1KagC+AoI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/powerquery-Dt-g_2cc.js"
    },
    {
      "hash": "sha256-mFY0nkOCtWd9xBsq2AhhUjBNMLSAV7n8qLKmNolX2kA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/powershell-B-7ap1zc.js"
    },
    {
      "hash": "sha256-ByjXEa4d9LOGEE31pGZc25WPLMemucxiJXPzgS3zC8w=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/protobuf-BmtuEB1A.js"
    },
    {
      "hash": "sha256-6Su1J6bJYd1+CwKN0gkSTHdqPyWmJTc8/uNlBq0jS1M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/pug-BRpRNeEb.js"
    },
    {
      "hash": "sha256-h8BBoBUOfGJt4o2DX8gdjewIMxRxpxu87qcSsrW9bUA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/python-Cr0UkIbn.js"
    },
    {
      "hash": "sha256-wr6r54dlQrzTYACIhjUeSEXRoDYCyjkaCfYOsg3MeHc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/qsharp-BzsFaUU9.js"
    },
    {
      "hash": "sha256-i35M8TAHzAK9+ruHgfrgpWvge9gXfhC61/9JZ0+Ryyo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/r-f8dDdrp4.js"
    },
    {
      "hash": "sha256-l3xZ/vYe2/pchh6hv4WUX4qL20dxpx9hSbfMFBbSDpg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/razor-BYAHOTkz.js"
    },
    {
      "hash": "sha256-yAbB5GZW0KE79mldeK+Jr7XLWNBQ7Q+FVy10qM3mlWg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/redis-fvZQY4PI.js"
    },
    {
      "hash": "sha256-l1C7zUDr/9cqqksqETofGYK3n9csGrhhagWCopVICVo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/redshift-45Et0LQi.js"
    },
    {
      "hash": "sha256-M+koXTtZCKXoVPpaNP3hP0wy/e1lJb+5lI+mTAQyt7A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/restructuredtext-C7UUFKFD.js"
    },
    {
      "hash": "sha256-VsejrlrFJQnnOY2j07ftFmRZhcjkZ5SuUm4QHWB0juA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/ruby-CZO8zYTz.js"
    },
    {
      "hash": "sha256-/wWybeIABDOtNa+98lD5b1XqpOhigE3toOrSfr30+aE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/rust-Bfetafyc.js"
    },
    {
      "hash": "sha256-Srr2mifBMOVc1SAuQrSOudllFbkWH2RoqrF4RZyFouQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sb-3GYllVck.js"
    },
    {
      "hash": "sha256-+axFlZgPZ/5N+cZUAt5y/DvNYjTKaCYk9TQn5y/CPIQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scala-foMgrKo1.js"
    },
    {
      "hash": "sha256-cI9/kx7lLa6dfLBCBmUSAnHjgQA3btV4VI66TfGNsSo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scheme-CHdMtr7p.js"
    },
    {
      "hash": "sha256-teg9ujoPrdM9PCna8DDvgxwdYVjHIRyK1MusUbWY2ng=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/scss-C1cmLt9V.js"
    },
    {
      "hash": "sha256-DdQN6wEhfy3o3wFLPqkQ3Od5St9YSWNvjDnBm/9Aq+s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/shell-ClXCKCEW.js"
    },
    {
      "hash": "sha256-+iZB1AzKFWwhzLqmYomB2+p7/LgJrwyGVBsx6Rz1gqA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/solidity-MZ6ExpPy.js"
    },
    {
      "hash": "sha256-IlpfPXUzexVvkOBcuz2euH8MXSYii9e1lkon1b0sP+4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sophia-DWkuSsPQ.js"
    },
    {
      "hash": "sha256-ajyGHjW0SkKIAhqGjVDdE1Nw7R1Vb8DZcp4APGBrqIM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sparql-AUGFYSyk.js"
    },
    {
      "hash": "sha256-kVhO/7Uy4LBS2AaRTDTlCH/uOVFtEmcgOCiHvw7vJo0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/sql-32GpJSV2.js"
    },
    {
      "hash": "sha256-QZ2fqCmIMpvkvOje5LFsI+HdnVqSXCtYqfInXROa4aI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/st-CuDFIVZ_.js"
    },
    {
      "hash": "sha256-t5jfEgHL/lUmbtvDYngBgOcs0IRHNJTXmxxWqz5raDs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/swift-n-2HociN.js"
    },
    {
      "hash": "sha256-ClxgvobPuxc7hjUDuvczNiEFkxcjiPA/9sDOji4IzLk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/systemverilog-Ch4vA8Yt.js"
    },
    {
      "hash": "sha256-xJLrZSq4JrmbLSUDv6ZRYu8U7vq9n12nC+0Dvu+6Ofg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/tcl-D74tq1nH.js"
    },
    {
      "hash": "sha256-4F96on4gQ2nDc41ArlYMnZSy1DbuRtR6NLC2X9sL2iY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/tsMode-CZz1Umrk.js"
    },
    {
      "hash": "sha256-u+tdL21tRXkLNnIMlpwatjsPrM/5qVC7SKqC2ZeiPLo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/twig-C6taOxMV.js"
    },
    {
      "hash": "sha256-C7Lf1RAKv4uYPwvXwbkEaC8PJhQmJvBBUqDqhAYRfAo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/typescript-DfOrAzoV.js"
    },
    {
      "hash": "sha256-N30owwcJg3BaET3HzdyebPnv9F7p1lPOT4O2Fg1+Op4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/typespec-D-PIh9Xw.js"
    },
    {
      "hash": "sha256-IphKWTUDz3CZRGnzk5oW1tJZJvPjLU2Rpf8or7bJIoU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/vb-Dyb2648j.js"
    },
    {
      "hash": "sha256-VecsiJ0qzG+3XOJ2V1HX0v857mwRcR9rFj14DWD6YtU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/wgsl-BhLXMOR0.js"
    },
    {
      "hash": "sha256-tyAEY73+fFh2oK3LQrVdHmw7D4VtQPMr9vv6cNEEAQU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/workers-DcJshg-q.js"
    },
    {
      "hash": "sha256-R1eEzyJXdcjQOVx/tZVTXU/sTNfi6hHm2p6bWQrBbbI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/xml-CdsdnY8S.js"
    },
    {
      "hash": "sha256-nUZg2FIYhxhHkgZmxuai0K1kI68Q+VEblecKu+AYZ3I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/yaml-DYGvmE88.js"
    },
    {
      "hash": "sha256-pDxJf09OT3Mk7I4HYgTz0Sk7AqoEZrD2qV7U/faFdSo=",
      "url": "_framework/BlazorMonaco.4geqh0sk8m.wasm"
    },
    {
      "hash": "sha256-H1Ff5w8USaxTHwy0bFZofbLVWBqGBUgROLSuL42B2QQ=",
      "url": "_framework/CsToml.Extensions.Configuration.33ji0wev9u.wasm"
    },
    {
      "hash": "sha256-WUnJFh7pLeyxkPo8SVEfHat9sk58nGqiWZ5ZUiMKXSA=",
      "url": "_framework/CsToml.zxq1wyha51.wasm"
    },
    {
      "hash": "sha256-NgXMGjmLgDNIB4eALSRAOFIRGrDH1bMpwfxgENpOnbY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.azg9v6n283.wasm"
    },
    {
      "hash": "sha256-KNp7I2ZPviL0X0CDM6FG9qufYlnepeLByzvAWV/+hLU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.49d7b3ljmx.wasm"
    },
    {
      "hash": "sha256-IUgYYp62R9GTwEvAbm3puH4LQDbto7m63svWiCqQmT0=",
      "url": "_framework/Microsoft.AspNetCore.Components.rxysge5f7v.wasm"
    },
    {
      "hash": "sha256-CYTyzqzpMXrdrFwO74HEWgFXKx7VUuhTZCh4C7FzEOI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.jx050q87pc.wasm"
    },
    {
      "hash": "sha256-kjRKz6YnjDNxBK++yFf5GuLFsdpANOBSUY/l9O8DJ5c=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.aicdglnrky.wasm"
    },
    {
      "hash": "sha256-zKbmUWrWRfCCnc97FMN6QD39RigNUo9RwiD/qsfdeEQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ghc4h4g85o.wasm"
    },
    {
      "hash": "sha256-5BpAYVVms759vbSwxDXcF947/prqU+G5QQmj9qy5gw4=",
      "url": "_framework/Microsoft.Extensions.Configuration.sut3hotea5.wasm"
    },
    {
      "hash": "sha256-jZMNv2YNX7bRhO/lW0+8FyQ//k686LheTVnNbXU3rpI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.3k227jqng1.wasm"
    },
    {
      "hash": "sha256-vEvSHSGyMQ3gh2S/J90gzUZ+9+WdytA2AEYHE/RlMCA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.gl0hjdtukf.wasm"
    },
    {
      "hash": "sha256-Ri2n41S/13i1DG5s+xYaenJ7mh4PCmRG76aCjWxf37w=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.urxzd0lv8l.wasm"
    },
    {
      "hash": "sha256-zrWsAFnvJGizhAZAZSFg+w4431hXmZpL196bRFw2daA=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.a2e0f1jf0h.wasm"
    },
    {
      "hash": "sha256-kqQt3pHQk/dm0UePIX8vJSR0nyVyC+h7T0Rt1j0mv+0=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.mvu94z3m15.wasm"
    },
    {
      "hash": "sha256-6uG63y2QF+ejnA6funJcFCp8cSgaIlBSRuqB39+fFpI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.68vclg0u0r.wasm"
    },
    {
      "hash": "sha256-2l+uLf4g/LtXhNF/ELp0BA39agCr7jQLRRr8ViQjYKs=",
      "url": "_framework/Microsoft.Extensions.Logging.uf2egbcy8t.wasm"
    },
    {
      "hash": "sha256-Z0etMzIoxwlCXHGJ7lU9QAvEPnSRT2ZdoQAExBuxosg=",
      "url": "_framework/Microsoft.Extensions.Options.rb0vc2abff.wasm"
    },
    {
      "hash": "sha256-22TrcPTRUf1PIpr+2moI+oX6J9gWGeo2s5Ul4mg0ANo=",
      "url": "_framework/Microsoft.Extensions.Primitives.z2391vf2jc.wasm"
    },
    {
      "hash": "sha256-gyCJ+c89twji71B7izFJaqfjuWG8Va471wHzIYG0+y4=",
      "url": "_framework/Microsoft.JSInterop.9hxczimrxw.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-IKuELEoyqhPnx6jLZOwTv4c1573bfGQ9bbQXxa7vHEQ=",
      "url": "_framework/SimpleTomlValidation.k3mgxoi1d6.wasm"
    },
    {
      "hash": "sha256-LZH/mND86RvICdmqcsAByKJjQDNwZcRdqhiXfiyF+7w=",
      "url": "_framework/System.Collections.Concurrent.njxwphyxdo.wasm"
    },
    {
      "hash": "sha256-LVhQfHc5kiJ7AHRH6jbuvaTQfXyszGcPe37eRh/LFaU=",
      "url": "_framework/System.Collections.Immutable.lmw46pxs1a.wasm"
    },
    {
      "hash": "sha256-ttoQo8r7EEVj2Ad0AUVR311jMbmGi815IBNJOXSr/XE=",
      "url": "_framework/System.Collections.ajcd26k4yr.wasm"
    },
    {
      "hash": "sha256-NlZsNZx4Xur0+uh1Yuxk+UvDQEDbsyymmXcD2XxiBSk=",
      "url": "_framework/System.ComponentModel.Primitives.a822u99snl.wasm"
    },
    {
      "hash": "sha256-FlqirVL9sIZuu5B2uysMetgDBYcJW58SWqLwNYQFKzY=",
      "url": "_framework/System.ComponentModel.e6bm8wniqf.wasm"
    },
    {
      "hash": "sha256-+UWU0FJ6GCOZ5IluXc4xpExCYoovz2vs/13mmYtmw7g=",
      "url": "_framework/System.Console.rv9omb9sbg.wasm"
    },
    {
      "hash": "sha256-n89wTpsMaM96SMD9bO42S9OSfJPQvoq64cLy0Jy2pD8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.j32sm00408.wasm"
    },
    {
      "hash": "sha256-pI7iHNUcL/pzXYV4G/Glh2DK6M0M0zrD9H8wmPvSUoY=",
      "url": "_framework/System.IO.FileSystem.Watcher.40ufxigcuk.wasm"
    },
    {
      "hash": "sha256-IELXkdthim/sV9Z9pmBB4sCTZprqKkphiAtSo7n5l5c=",
      "url": "_framework/System.IO.Hashing.8ypaol9wnh.wasm"
    },
    {
      "hash": "sha256-NfUmMn1IBXrdMZW7lVw6OdQjH0DJvlNue/65XdW/A/A=",
      "url": "_framework/System.IO.Pipelines.ro19e7p3es.wasm"
    },
    {
      "hash": "sha256-RC8i/jroOKzFPtV1JLZjt22FCLH7PV9QZ+zTb6Bm1s4=",
      "url": "_framework/System.Linq.8tmx76aslq.wasm"
    },
    {
      "hash": "sha256-g0Lo61P3rRdIFDZbFuTvrXlNpKhmC5wCUQZtRTHRDG0=",
      "url": "_framework/System.Memory.zsnczrn2wq.wasm"
    },
    {
      "hash": "sha256-exXl2m3otqUyKff8lYkstlb/ZDv5kmLjQHsdDMYLM2U=",
      "url": "_framework/System.Net.Http.fvx4lzj36h.wasm"
    },
    {
      "hash": "sha256-KcKljuzikM+4vwo+CqRdWk+QmzHHT9E/sfyHh8sFYMg=",
      "url": "_framework/System.Net.Primitives.vu0y1pa3d8.wasm"
    },
    {
      "hash": "sha256-DDzrJ6+toDnx7FZu/hsKs3HRzMbxgI52e0iRx+B3KXM=",
      "url": "_framework/System.Private.CoreLib.s6430j6k53.wasm"
    },
    {
      "hash": "sha256-OeIB1YEIuMdvs1o6Gp2EfrY9K/ZzEiEHsOGPebqtkiA=",
      "url": "_framework/System.Private.Uri.9sg9dadvaf.wasm"
    },
    {
      "hash": "sha256-PqykTsnB/X8Wd8ZWRG6+IlOUa+0hu2JCcbXmx9FyDII=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.6ec2lj6df3.wasm"
    },
    {
      "hash": "sha256-+1R7f7rDNRNuiCIdPVRQCs847Hm/likh3+Nbn1GJrGs=",
      "url": "_framework/System.Runtime.Numerics.b4itcutzsg.wasm"
    },
    {
      "hash": "sha256-RT+h0vYPwRcl3OXg5gzH/GU2mm4vaRJoCxnYcebEh1Q=",
      "url": "_framework/System.Runtime.xln7ke0dtk.wasm"
    },
    {
      "hash": "sha256-z9fdbzbjxrUJQQL1ec967hUeFha+enI3j3TR6/+eM1I=",
      "url": "_framework/System.Security.Cryptography.7mnpwlcte2.wasm"
    },
    {
      "hash": "sha256-pNsbAxrOrTV72dS8/Z05nkltnjNZWGtIhVx4asmdKj0=",
      "url": "_framework/System.Text.Encodings.Web.saysj3e25v.wasm"
    },
    {
      "hash": "sha256-DAB7nZe2PandKmcgmk02eNcITc1vqtDf5BDE5e0FPA0=",
      "url": "_framework/System.Text.Json.k4h1zsoe45.wasm"
    },
    {
      "hash": "sha256-A7HuKk+OI081jzfETpsKJCogGCvULLIJfYmZJuMmOzU=",
      "url": "_framework/System.Text.RegularExpressions.nz47wj5o6d.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Gp/BnUb0eubpQyzzKPw56L6UqXMLPB1dUNHMjQPP/E8=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-PqYGZSJJJ6rpvz1FA7fr4AkGLHIz06BKJBbYbwbD4qc=",
      "url": "_framework/dotnet.native.e97097xgfh.wasm"
    },
    {
      "hash": "sha256-oMKcK2WBBhQKTxnjTd/kn/pAdTri7CxE05eMWf8lbGM=",
      "url": "_framework/dotnet.native.oikbiht2hk.js"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-sc4S6472blqr4ANUZi7N6AhCY9wUOIQWFucoHxJBAVA=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-ln6kGi5L123gAP6hE9szChTONz9e51hN+KO7BrFxUeM=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-ofx4Eq3Yl0T7I7lm0litMu7QBBUsC1bn6kTH+Gaojms=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-9UmaHqTHm9jqAuyU7SCKpFLW5V9oqw/t3JJWlTtRVWI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-tBJ5Q+Y/QGEGoQXkiEeTWus9AYjSb4Xwfh9WGZ5JKmA=",
      "url": "manifest.webmanifest"
    }
  ]
};
